<?php

return [
    'eligibility' => 'You are not eligible for this plan based on your current number of '.str_plural(Spark::teamString()).' / '.Spark::teamString().' members.'
];
