module.exports = {
    props: ['user', 'teams'],
};
