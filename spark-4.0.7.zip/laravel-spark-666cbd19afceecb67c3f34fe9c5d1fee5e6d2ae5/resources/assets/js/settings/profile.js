module.exports = {
    props: ['user']
};
