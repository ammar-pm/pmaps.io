Hi!

<br><br>

{{ $invitation->team->owner->name }} has invited you to join their {{ Spark::teamString() }}!

<br><br>

Since you already have an account, you may accept the invitation from your
account settings screen.

<br><br>

See you soon!
