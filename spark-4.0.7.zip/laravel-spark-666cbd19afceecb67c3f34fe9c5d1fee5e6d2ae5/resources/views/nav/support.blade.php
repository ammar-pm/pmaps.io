<li class="dropdown-header">Support</li>

<!-- Support -->
<li>
    <a @click.prevent="showSupportForm" style="cursor: pointer;">
        <i class="fa fa-fw fa-btn fa-paper-plane"></i>Email Us
    </a>
</li>

<li class="divider"></li>
