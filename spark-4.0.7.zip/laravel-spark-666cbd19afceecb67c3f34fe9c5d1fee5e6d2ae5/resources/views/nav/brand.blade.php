<a class="navbar-brand" href="/home">
    <img src="/img/mono-logo.png" style="height: 32px;">
</a>
