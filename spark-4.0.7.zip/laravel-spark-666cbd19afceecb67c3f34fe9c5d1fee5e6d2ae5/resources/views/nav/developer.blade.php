<li class="dropdown-header">Developer</li>

<!-- Kiosk -->
<li>
    <a href="/spark/kiosk">
        <i class="fa fa-fw fa-btn fa-fort-awesome"></i>Kiosk
    </a>
</li>

<li class="divider"></li>
