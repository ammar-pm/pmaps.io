var base = require('settings/teams/create-team');

Vue.component('spark-create-team', {
    mixins: [base]
});
