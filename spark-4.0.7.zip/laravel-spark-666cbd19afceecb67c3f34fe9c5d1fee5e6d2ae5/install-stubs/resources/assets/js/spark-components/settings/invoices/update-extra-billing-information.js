var base = require('settings/invoices/update-extra-billing-information');

Vue.component('spark-update-extra-billing-information', {
    mixins: [base]
});
