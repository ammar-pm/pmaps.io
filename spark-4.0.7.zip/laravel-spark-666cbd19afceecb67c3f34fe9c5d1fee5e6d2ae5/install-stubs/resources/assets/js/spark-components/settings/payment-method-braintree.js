var base = require('settings/payment-method-braintree');

Vue.component('spark-payment-method-braintree', {
    mixins: [base]
});
