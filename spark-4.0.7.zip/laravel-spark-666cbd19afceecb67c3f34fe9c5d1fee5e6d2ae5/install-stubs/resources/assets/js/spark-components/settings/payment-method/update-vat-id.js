var base = require('settings/payment-method/update-vat-id');

Vue.component('spark-update-vat-id', {
    mixins: [base]
});
