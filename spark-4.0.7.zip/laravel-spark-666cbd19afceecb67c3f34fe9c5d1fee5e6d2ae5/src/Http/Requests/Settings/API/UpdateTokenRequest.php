<?php

namespace Laravel\Spark\Http\Requests\Settings\API;

class UpdateTokenRequest extends TokenRequest
{
    //
}
