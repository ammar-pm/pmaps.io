<?php

namespace Laravel\Spark\Http\Requests\Settings\API;

class CreateTokenRequest extends TokenRequest
{
    //
}
