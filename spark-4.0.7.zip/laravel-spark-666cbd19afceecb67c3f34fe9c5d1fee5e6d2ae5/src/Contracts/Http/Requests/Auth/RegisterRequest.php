<?php

namespace Laravel\Spark\Contracts\Http\Requests\Auth;

interface RegisterRequest
{
    //
}
