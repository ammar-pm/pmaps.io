<?php

namespace Laravel\Spark\Contracts\Http\Requests\Settings\PaymentMethod;

interface UpdatePaymentMethodRequest
{
    //
}
