<?php

namespace Laravel\Spark\Contracts\Http\Requests\Settings\Subscription;

interface CreateSubscriptionRequest
{
    //
}
