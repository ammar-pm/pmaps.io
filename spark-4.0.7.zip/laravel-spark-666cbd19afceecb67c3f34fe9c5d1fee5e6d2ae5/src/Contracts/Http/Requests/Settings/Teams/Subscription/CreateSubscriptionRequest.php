<?php

namespace Laravel\Spark\Contracts\Http\Requests\Settings\Teams\Subscription;

interface CreateSubscriptionRequest
{
    //
}
